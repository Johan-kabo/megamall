#include<stdio.h>
int main(){
    int main
    int a,b,SOM;
    Printf("Entrer vos deux nombres");
    scanf('%d',&a,&b);
    SOM = a + b;
    Printf("La somme de vos deux nombres est:%d");

    Return 0;
    
}